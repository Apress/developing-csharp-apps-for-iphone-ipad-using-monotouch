
using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace Example_HandlingRotation.Screens.iPad.Method1Autosize
{
	public partial class AutosizeScreen : UIViewController
	{
		List<string> _tableItems = new List<string> ();

		#region Constructors

		// The IntPtr and initWithCoder constructors are required for controllers that need 
		// to be able to be created from a xib rather than from managed code

		public AutosizeScreen (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		[Export("initWithCoder:")]
		public AutosizeScreen (NSCoder coder) : base(coder)
		{
			Initialize ();
		}

		public AutosizeScreen () : base("AutosizeScreen", null)
		{
			Initialize ();
		}

		void Initialize ()
		{
		}

		#endregion

		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			
			this.Title = "Autosizing Controls";
			
			this.CreateData ();
			
			this.tblMain.WeakDataSource = this;
		}

		//========================================================================
		/// <summary>
		/// When the device rotates, the OS calls this method to determine if it should try and rotate the
		/// application and then call WillAnimateRotation
		/// </summary>
		public override bool ShouldAutorotateToInterfaceOrientation (UIInterfaceOrientation toInterfaceOrientation)
		{
			//---- we're passed to orientation that it will rotate to. in our case, we could
			// just return true, but this switch illustrates how you can test for the 
			// different cases
			switch (toInterfaceOrientation)
			{
				case UIInterfaceOrientation.LandscapeLeft:
				case UIInterfaceOrientation.LandscapeRight:
				case UIInterfaceOrientation.Portrait:
				case UIInterfaceOrientation.PortraitUpsideDown:
				default:
					return true;
			}
		}
		//========================================================================


		protected void CreateData ()
		{
			this._tableItems.Add ("Radiohead");
			this._tableItems.Add ("Death Cab for Cutie");
			this._tableItems.Add ("Earlimart");
			this._tableItems.Add ("Grandaddy");
			this._tableItems.Add ("Wonderful");
			this._tableItems.Add ("Sufjan Stevens");
			this._tableItems.Add ("Johnny Cash");
			this._tableItems.Add ("New Order");
			this._tableItems.Add ("Elliott Smith");
			this._tableItems.Add ("Elbow");
		}

		[Export("tableView:numberOfRowsInSection:")]
		public int RowsInSection (UITableView tableView, int section)
		{
			Console.WriteLine ("RowsInSection");
			return this._tableItems.Count;
		}

		[Export("tableView:cellForRowAtIndexPath:")]
		public UITableViewCell GetCell (UITableView tableView, NSIndexPath indexPath)
		{
			Console.WriteLine ("GetCell");
			
			//---- declare vars
			string cellIdentifier = "SimpleCellTemplate";
			
			//---- try to grab a cell object from the internal queue
			var cell = tableView.DequeueReusableCell (cellIdentifier);
			//---- if there wasn't any available, just create a new one
			if (cell == null)
			{
				cell = new UITableViewCell (UITableViewCellStyle.Default, cellIdentifier);
			}
			
			//---- set the cell properties
			cell.TextLabel.Text = this._tableItems[indexPath.Row];
			
			//---- return the cell
			return cell;
		}
	}
}

