using System;
using MonoTouch.UIKit;
using System.Drawing;

namespace Example_SwitchingControllers.Screens
{
	public class MainViewController : UIViewController
	{
		//========================================================================
		#region -= declarations =-
		
		/// <summary>
		/// Which view is currently on the stack
		/// </summary>
		protected WhichView _whichViewIsCurrent = WhichView.ViewOne;
		/// <summary>
		/// The current UIView on the stack
		/// </summary>
		protected UIView _currentSubView;
		
		#endregion
		//========================================================================
		
		//========================================================================
		#region -= constructors =-

		//========================================================================
		public MainViewController () : base()
		{
		}
		//========================================================================		
		
		#endregion
		//========================================================================

		//========================================================================
		#region -= lifecycle mthods =-
		
		//========================================================================
		/// <summary>
		/// Loads our custom view
		/// </summary>
		public override void LoadView ()
		{
			Console.WriteLine ("LoadView() Called");
			
			//---- we have to call this if we don't replace the root view otherwise, 
			// when we access this.View, it will call this method and get stuck in 
			// and endless loop
			base.LoadView ();
			
			//---- instantiate our custom view
			this._currentSubView = new MainViewOne (new RectangleF (new PointF (0, 0), UIScreen.MainScreen.ApplicationFrame.Size));
			//---- add it to the stack
			this.View.AddSubview (this._currentSubView);
			//this.View = this._currentSubView;
			
			//---- add a button to alow us to switch back and forth
			this.AddButton ();
		}
		//========================================================================
		
		#endregion
		//========================================================================
		
		//========================================================================
		#region -= protected methods =-
		
		//========================================================================
		/// <summary>
		/// Switches between the two views by pulling the old one off the stack 
		/// and puts the new one on. Also animates the transition.
		/// </summary>
		protected void SwitchViews ()
		{
			Console.WriteLine ("Switching Views");
			
//			UIView.Animate(.5, 0, UIViewAnimationOptions.TransitionFlipFromRight, () => {
//				//---- depending on which view is currently loaded, load the other one
//				switch (this._whichViewIsCurrent)
//				{
//					case WhichView.ViewOne:
//						//---- remove the view from the stack so it can be garbage collected
//						this._currentSubView.RemoveFromSuperview ();
//						//---- instantiate the new view
//						this._currentSubView = new MainViewTwo (new RectangleF (new PointF (0, 0), UIScreen.MainScreen.ApplicationFrame.Size));
//						//---- add the view to the stack
//						this.View.AddSubview (this._currentSubView);
//						//this.View = this._currentSubView;
//						//---- save which view is current
//						this._whichViewIsCurrent = WhichView.ViewTwo;
//						break;
//					
//					case WhichView.ViewTwo:
//						this._currentSubView.RemoveFromSuperview ();
//						this._currentSubView = new MainViewOne (new RectangleF (new PointF (0, 0), UIScreen.MainScreen.ApplicationFrame.Size));
//						this.View.AddSubview (this._currentSubView);
//						//this.View = this._currentSubView;
//						this._whichViewIsCurrent = WhichView.ViewOne;
//						break;
//				}
//				
//			}, null);
			
			//---- begin an animation block
			UIView.BeginAnimations ("View Flip");
			// number of seconds
			UIView.SetAnimationDuration (1.25);
			// the curve of the transition speed
			UIView.SetAnimationCurve (UIViewAnimationCurve.EaseInOut);
			// the type of transition animation
			UIView.SetAnimationTransition (UIViewAnimationTransition.FlipFromRight, this.View, true);
			
			//---- depending on which view is currently loaded, load the other one
			switch (this._whichViewIsCurrent)
			{
				case WhichView.ViewOne:
					//---- remove the view from the stack so it can be garbage collected
					this._currentSubView.RemoveFromSuperview ();
					//---- instantiate the new view
					this._currentSubView = new MainViewTwo (new RectangleF (new PointF (0, 0), UIScreen.MainScreen.ApplicationFrame.Size));
					//---- add the view to the stack
					this.View.AddSubview (this._currentSubView);
					//---- save which view is current
					this._whichViewIsCurrent = WhichView.ViewTwo;
					break;
				
				case WhichView.ViewTwo:
					this._currentSubView.RemoveFromSuperview ();
					this._currentSubView = new MainViewOne (new RectangleF (new PointF (0, 0), UIScreen.MainScreen.ApplicationFrame.Size));
					this.View.AddSubview (this._currentSubView);
					this._whichViewIsCurrent = WhichView.ViewOne;
					break;
			}

			//---- end our animation block
			UIView.CommitAnimations ();
			
			//---- add our button to the newly loaded view
			this.AddButton ();
		}
		//========================================================================
		
		//========================================================================
		/// <summary>
		/// Adds a "switch views" button to the current view
		/// </summary>
		protected void AddButton ()
		{
			//---- create a new button
			UIButton btnSwitchView = UIButton.FromType (UIButtonType.RoundedRect);
			btnSwitchView.Frame = new System.Drawing.RectangleF (10f, 40f, 100f, 33f);
			// set the buttons text
			btnSwitchView.SetTitle ("Switch Views", UIControlState.Normal);
			// wire up the click
			btnSwitchView.TouchUpInside += delegate { this.SwitchViews (); };
			// add the button to the current view
			this._currentSubView.AddSubview (btnSwitchView);
		}
		//========================================================================
		
		#endregion
		//========================================================================
		
		//========================================================================
		/// <summary>
		/// Used to track which view is up
		/// </summary>
		protected enum WhichView
		{
			ViewOne,
			ViewTwo
		}
		//========================================================================
	}
}

