using System;
using MonoTouch.UIKit;
using System.Drawing;
using MonoTouch.CoreGraphics;

namespace Example_SwitchingControllers.Screens
{
	public class MainViewOne : UIView
	{
		//========================================================================
		#region -= constructors =-

		//========================================================================
		public MainViewOne (RectangleF frame) : base(frame)
		{
		}
		//========================================================================

		#endregion
		//========================================================================

		//========================================================================
		/// <summary>
		/// This method is called the first time the view is displayed, and after 
		/// anytime we tell the OS that the view needs to be redrawn, by calling 
		/// SetNeedsDisplay() or SetNeedsDisplayInRect().
		/// 
		/// We may, in certain cases want to use this method to manualy add subviews.
		/// 
		/// This is the only time we have direct access to the drawing surface, 
		/// if we want to make direct drawing calls.
		/// </summary>
		public override void Draw (System.Drawing.RectangleF rect)
		{
			base.Draw (rect);
			
			using (CGContext context = UIGraphics.GetCurrentContext ())
			{
				// Start with filling the whole image with a
				// blue background
				context.SetRGBFillColor (0.8f, 0.8f, 1f, 1f);
				context.FillRect (rect);
			}
		}
		//========================================================================
		
		//========================================================================
		/// <summary>
		/// This is called just before the view is displayed. if we have views as 
		/// children, and we want to customize how they're displayed/positioned, 
		/// then we can do it here.
		/// </summary>
		public override void LayoutSubviews ()
		{
			base.LayoutSubviews ();
		}
		//========================================================================		
		
	}
}

