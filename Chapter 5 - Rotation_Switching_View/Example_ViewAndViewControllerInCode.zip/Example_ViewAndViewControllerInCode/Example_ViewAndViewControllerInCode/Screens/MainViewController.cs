using System;
using MonoTouch.UIKit;
using System.Drawing;

namespace Example_ViewAndViewControllerInCode.Screens
{
	public class MainViewController : UIViewController
	{
		
		//========================================================================
		#region -= constructors =-
	
		//========================================================================
		public MainViewController () : base()
		{
		}
		//========================================================================
	
		#endregion
		//========================================================================
	
		//========================================================================
		#region -= event lifecycle methods =-
		
		//========================================================================
		public override void LoadView ()
		{
			Console.WriteLine ("LoadView() Called");
			//---- replace the default view with our custom view
			this.View = new MainView (UIScreen.MainScreen.ApplicationFrame);
		}
		//========================================================================

		//========================================================================		
		/// <summary>
		/// 
		/// </summary>
		public override void ViewDidLoad ()
		{
			Console.Write ("ViewDidLoad() Called");
			base.ViewDidLoad ();
			
			//---- add any controls
			UILabel lblHello = new UILabel (new System.Drawing.RectangleF (10f, 40f, 100f, 33f));
			lblHello.Text = "Hello!!";
			lblHello.BackgroundColor = UIColor.Clear;
			this.View.AddSubview (lblHello);
		}
		//========================================================================
				
		#endregion
		//========================================================================	
	}
	}

